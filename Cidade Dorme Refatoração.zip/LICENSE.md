Copyright (c) [2025] [Fernando Sérgio]

Todos os direitos reservados.

É concedida permissão para visualizar o código-fonte contido neste repositório para fins educacionais e de referência.

Fica expressamente proibido, sem a permissão prévia por escrito do detentor dos direitos autorais:
1. A cópia, modificação ou distribuição de qualquer parte deste software.
2. A utilização deste software, no todo ou em parte, para criar um trabalho derivado.
3. A utilização deste software para fins comerciais, incluindo, mas não se limitando a, hospedagem de uma instância pública ou privada do bot para monetização ou serviço.

Para consultas sobre licenciamento ou permissões, entre em contato com [cidadedorme6@gmail.com].